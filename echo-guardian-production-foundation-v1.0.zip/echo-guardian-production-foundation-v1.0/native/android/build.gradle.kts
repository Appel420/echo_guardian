plugins {
    id("com.android.library") version "8.5.2" apply false
    kotlin("android") version "1.9.24" apply false
}
